pub mod protocol;
pub mod light_protocol;
pub mod amino;
use light_protocol::{LightRequest, LightResponse, LIGHT_PROTOCOL, LIGHT_PUSH_PROTOCOL, LightNotification};

pub use protocol::{Message, MidstateCodec, MIDSTATE_PROTOCOL, MAX_GETBATCHES_COUNT, MAX_GETHEADERS_COUNT};

use anyhow::Result;
use futures::StreamExt;
use libp2p_core::muxing::StreamMuxerBox;
use libp2p::{
    autonat,
    dcutr,
    identify, kad,
    noise,
    relay,
    request_response::{
        self, Config as RequestResponseConfig, OutboundRequestId, ProtocolSupport,
        ResponseChannel,
    },
    swarm::{NetworkBehaviour, SwarmEvent},
    tcp, yamux,
    identity::Keypair,
    Multiaddr, PeerId, Swarm,
    core::ConnectedPoint,
    Transport    
};

use std::collections::{HashMap, HashSet};
use std::net::SocketAddr;
use std::time::Duration;
use std::net::IpAddr;
use std::sync::Arc;
use std::time::Instant;

/// Max addresses to send in a single PEX Addr message.
pub const MAX_PEX_ADDRS: usize = 50;

// ── Light Client Protection Constants ────────────────────────────────────────

/// Maximum concurrent WebRTC light client connections.
const MAX_LIGHT_PEERS: usize = 500;
/// Maximum concurrent streams (requests in flight) per light peer.
const MAX_LIGHT_STREAMS_PER_PEER: usize = 50;
/// Rate limit window in seconds.
const LIGHT_RATE_WINDOW_SECS: u64 = 60;

/// Number of rate-limit violations before temporary ban.
const LIGHT_BAN_THRESHOLD: u32 = 20;
/// Duration of a temporary ban in seconds.
const LIGHT_BAN_DURATION_SECS: u64 = 500;
/// Timeout waiting for a light client to send its request data.
const LIGHT_READ_TIMEOUT_SECS: u64 = 10;
/// Timeout waiting for the node to produce a response.
const LIGHT_RESPONSE_TIMEOUT_SECS: u64 = 30;

// ── Light Client Rate Limiter ────────────────────────────────────────────────

struct LightPeerState {
    request_count: u32,
    expensive_count: u32,
    window_start: Instant,
    active_streams: u32,
    violations: u32,
    banned_until: Option<Instant>,
    
    // --- BAYESIAN REPUTATION (Beta Distribution) ---
    /// Prior: successful cryptographic proofs (Honest)
    alpha: u32, 
    /// Prior: failed proofs, spam, or timeouts (Adversarial)
    beta: u32,  
}

impl LightPeerState {
    fn new() -> Self {
        Self {
            request_count: 0,
            expensive_count: 0,
            window_start: Instant::now(),
            active_streams: 0,
            violations: 0,
            banned_until: None,
            // Uniform prior: We start neutral, assuming 1 good and 1 bad interaction
            alpha: 1, 
            beta: 1,
        }
    }

/// Calculate dynamic rate limit based on the Expected Value of the Beta distribution
    fn current_rate_limit(&self) -> u32 {
        // E[X] = alpha / (alpha + beta). 
        // Approaches 1.0 for honest peers, approaches 0.0 for malicious peers.
        let probability_honest = self.alpha as f32 / (self.alpha + self.beta) as f32;

        // If the probability they are honest drops below 10%, throttle them to the floor
        if probability_honest < 0.1 {
            return 5; // 5 requests per minute maximum
        }

        // Base rate for unknown peers (0.5 prob) is ~275. Highly trusted peers scale up to ~500.
        (50.0 + (450.0 * probability_honest)) as u32
    }

    fn current_expensive_limit(&self) -> u32 {
        let probability_honest = self.alpha as f32 / (self.alpha + self.beta) as f32;
        if probability_honest < 0.2 { return 5; }
        // Base 20, max 200. A new peer (0.5 prob) gets 120 requests per minute.
        // 120 requests * 1000 blocks = 120,000 blocks synced per minute over WebRTC.
        (20.0 + (200.0 * probability_honest)) as u32
    }

    /// Reset counters if the window has elapsed.
    fn maybe_reset_window(&mut self) {
        if self.window_start.elapsed().as_secs() >= LIGHT_RATE_WINDOW_SECS {
            self.request_count = 0;
            self.expensive_count = 0;
            self.window_start = Instant::now();
        }
    }

    fn is_banned(&self) -> bool {
        self.banned_until.map_or(false, |t| Instant::now() < t)
    }
}

/// Thread-safe light client rate limiter shared between the event loop
/// and spawned stream-handling tasks.
#[derive(Clone)]
struct LightGuard {
    inner: Arc<tokio::sync::Mutex<LightGuardInner>>,
}

struct LightGuardInner {
    peers: HashMap<PeerId, LightPeerState>,
}

impl LightGuard {
    fn new() -> Self {
        Self {
            inner: Arc::new(tokio::sync::Mutex::new(LightGuardInner {
                peers: HashMap::new(),
            })),
        }
    }

    /// Check if a new stream should be allowed. Returns Err(reason) if denied.
    async fn try_open_stream(&self, peer: PeerId) -> Result<(), &'static str> {
        let mut guard = self.inner.lock().await;
        let state = guard.peers.entry(peer).or_insert_with(LightPeerState::new);

        if state.is_banned() {
            return Err("peer is temporarily banned");
        }

        state.maybe_reset_window();

        if state.active_streams >= MAX_LIGHT_STREAMS_PER_PEER as u32 {
            state.violations += 1;
            if state.violations >= LIGHT_BAN_THRESHOLD {
                state.banned_until = Some(Instant::now() + Duration::from_secs(LIGHT_BAN_DURATION_SECS));
                return Err("banned: too many concurrent streams");
            }
            return Err("too many concurrent streams");
        }

        if state.request_count >= state.current_rate_limit() {
            state.violations += 1;
            if state.violations >= LIGHT_BAN_THRESHOLD {
                state.banned_until = Some(Instant::now() + Duration::from_secs(LIGHT_BAN_DURATION_SECS));
                return Err("banned: rate limit exceeded");
            }
            return Err("rate limit exceeded");
        }

        state.active_streams += 1;
        state.request_count += 1;
        Ok(())
    }

    /// Check if an expensive request (BlockTemplate) is allowed.
    /// Call AFTER try_open_stream succeeds.
    async fn check_expensive(&self, peer: PeerId) -> bool {
        let mut guard = self.inner.lock().await;
        if let Some(state) = guard.peers.get_mut(&peer) {
            state.maybe_reset_window();
            if state.expensive_count >= state.current_expensive_limit() {
                state.violations += 1;
                if state.violations >= LIGHT_BAN_THRESHOLD {
                    state.banned_until = Some(Instant::now() + Duration::from_secs(LIGHT_BAN_DURATION_SECS));
                }
                return false;
            }
            state.expensive_count += 1;
        }
        true
    }

    /// Decrement the active stream counter when a stream finishes.
    async fn close_stream(&self, peer: PeerId) {
        let mut guard = self.inner.lock().await;
        if let Some(state) = guard.peers.get_mut(&peer) {
            state.active_streams = state.active_streams.saturating_sub(1);
        }
    }

    /// Remove all state for a disconnected peer.
    async fn remove_peer(&self, peer: &PeerId) {
        let mut guard = self.inner.lock().await;
        guard.peers.remove(peer);
    }

    /// Check if a peer is currently banned.
    async fn is_banned(&self, peer: &PeerId) -> bool {
        let guard = self.inner.lock().await;
        guard.peers.get(peer).map_or(false, |s| s.is_banned())
    }

  
/// BAYESIAN INFERENCE: Observe an honest interaction
    async fn observe_honest(&self, peer: PeerId) {
        let mut guard = self.inner.lock().await;
        if let Some(state) = guard.peers.get_mut(&peer) {
            // Cap at 10,000 exactly like your FinalityEstimator to prevent overflow
            state.alpha = state.alpha.saturating_add(1).min(10_000);
        }
    }

    /// BAYESIAN INFERENCE: Observe an adversarial interaction
    async fn observe_adversarial(&self, peer: PeerId) {
        let mut guard = self.inner.lock().await;
        if let Some(state) = guard.peers.get_mut(&peer) {
            // Penalize faster than we reward (1 bad act = 10 good acts)
            state.beta = state.beta.saturating_add(10).min(10_000);
            
            // Auto-ban if the probability of honesty collapses completely
            if state.beta > state.alpha * 10 {
                state.banned_until = Some(Instant::now() + Duration::from_secs(LIGHT_BAN_DURATION_SECS));
            }
        }
    }
    
    /// Garbage-collect stale peer entries that have no active streams and
    /// whose rate-limit window hasn't been touched in over an hour.
    /// Prevents unbounded memory growth from peers that connect once and vanish.
    async fn gc_stale(&self) {
        let mut guard = self.inner.lock().await;
        let stale_threshold = Duration::from_secs(3600);
        guard.peers.retain(|_, state| {
            // Keep peers with active streams, active bans, or recent activity
            state.active_streams > 0
                || state.is_banned()
                || state.window_start.elapsed() < stale_threshold
        });
    }
}



// ── Behaviour ───────────────────────────────────────────────────────────────

#[derive(NetworkBehaviour)]
pub struct MidstateBehaviour {
    pub rr: request_response::Behaviour<MidstateCodec>,
    pub light: libp2p_stream::Behaviour,
    pub kademlia: kad::Behaviour<kad::store::MemoryStore>,
    pub identify: identify::Behaviour,
    pub relay_client: relay::client::Behaviour,
    pub relay_server: relay::Behaviour,
    pub dcutr: dcutr::Behaviour,
    pub autonat: autonat::Behaviour,
    pub connection_limits: libp2p::connection_limits::Behaviour, 
}

// ── NAT status ──────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NatStatus {
    Unknown,
    Public,
    Private,
}

// ── Events ──────────────────────────────────────────────────────────────────

pub enum NetworkEvent {
    MessageReceived {
        peer: PeerId,
        message: Message,
        channel: Option<ResponseChannel<Message>>,
    },
    LightRequest {
        peer: PeerId,
        request: LightRequest,
        /// Oneshot sender: drop it or send the response; the stream-writing
        /// task in next_event() will write it back to the browser.
        respond: tokio::sync::oneshot::Sender<LightResponse>,
    },
    PeerConnected(PeerId, String),
    PeerDisconnected(PeerId),
    OutgoingConnectionFailed(String),
    RequestFailed(PeerId),
    /// Peer completed a libp2p handshake but advertises none of our
    /// request-response protocols — a fork or an incompatible release.
    /// Handled as a ban: it will never answer, and the subnet is as good a
    /// signal as the peer id.
    ProtocolMismatch(PeerId),
}

// ── Network API ─────────────────────────────────────────────────────────────

    pub fn is_routable(addr: &Multiaddr) -> bool {
        for proto in addr.iter() {
            match proto {
                libp2p::multiaddr::Protocol::Ip4(ip) => {
                    // Reject Loopback, Private (RFC 1918), and Link-local
                    if ip.is_loopback() || ip.is_private() || ip.is_link_local() { return false; }
                    // 0.0.0.0 is caught by none of the above — is_private() only
                    // covers 10/8, 172.16/12 and 192.168/16 — so a wildcard listen
                    // address would otherwise be gossiped as if it were dialable.
                    if ip.is_unspecified() || ip.is_broadcast() || ip.is_multicast() { return false; }
                    // Carrier-grade NAT (RFC 6598). A node behind CGNAT sees a
                    // non-RFC1918 address and wrongly believes it is public.
                    let o = ip.octets();
                    if o[0] == 100 && (64..128).contains(&o[1]) { return false; }
                    // Benchmarking (RFC 2544) and TEST-NET documentation ranges.
                    if o[0] == 198 && (o[1] == 18 || o[1] == 19) { return false; }
                }
                libp2p::multiaddr::Protocol::Ip6(ip) => {
                    // Reject Loopback and Link-local
                    if ip.is_loopback() || (ip.segments()[0] & 0xff00 == 0xfe00) { return false; }
                    // Unspecified (::) and Unique Local Addresses (fc00::/7).
                    if ip.is_unspecified() || (ip.segments()[0] & 0xfe00) == 0xfc00 { return false; }
                }
                // A relayed address describes a path through someone else's node,
                // not a routable identity for this one. Treating it as routable is
                // what let relay IPs leak into the seed registry.
                libp2p::multiaddr::Protocol::P2pCircuit => return false,
                _ => {}
            }
        }
        true
    }

/// Canonical URL of the stateless seed registry (Cloudflare Worker).
pub const PHONEBOOK_URL: &str = "https://seeds.midstate.cash";

/// Fetches the current live peer set from the seed registry.
///
/// # Reasoning
/// Lives in the library (not `main.rs`) so the running node event loop can
/// re-query the registry periodically, rather than reading it exactly once at
/// process startup.
///
/// # Safety / Invariants
/// - **Bounded Execution:** A 5s timeout ensures neither startup nor the node
///   event loop can stall on a registry that is offline, censored, or
///   blackholed.
pub async fn fetch_phonebook_peers(url: &str) -> anyhow::Result<Vec<String>> {
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(5))
        .build()?;

    let resp = client.get(format!("{}/peers", url)).send().await?;
    if !resp.status().is_success() {
        anyhow::bail!("Phonebook returned status: {}", resp.status());
    }
    Ok(resp.json::<Vec<String>>().await?)
}

pub struct MidstateNetwork {
    swarm: Swarm<MidstateBehaviour>,
    /// Incoming raw streams from browser light clients.
    light_incoming: libp2p_stream::IncomingStreams,
    /// Light requests parsed in spawned tasks (so swarm keeps being polled).
    light_rx: tokio::sync::mpsc::UnboundedReceiver<(
        PeerId,
        LightRequest,
        tokio::sync::oneshot::Sender<LightResponse>,
    )>,
    light_tx: tokio::sync::mpsc::UnboundedSender<(
        PeerId,
        LightRequest,
        tokio::sync::oneshot::Sender<LightResponse>,
    )>,
    /// Rate limiter / abuse protection for light protocol.
    light_guard: LightGuard,
    /// Peers that connected via WebRTC (light-only, don't speak binary protocol).
    light_peers: HashSet<PeerId>,
    connected: HashMap<PeerId, ConnectedPoint>,
    pending_requests: HashMap<OutboundRequestId, PeerId>,
    nat_status: NatStatus,
    /// Set when the operator has declared this node publicly reachable in
    /// config. Overrides AutoNAT, which has been observed flapping
    /// Public → Private on demonstrably reachable hosts and silently stopping
    /// registry and DHT announcements as a result.
    declared_public: bool,
    relay_reservations: HashSet<PeerId>,
    listen_addrs: Vec<Multiaddr>,
    external_addrs: Vec<Multiaddr>,
    subnet_peers: HashMap<IpAddr, HashSet<PeerId>>,
    pub banned_subnets: HashMap<IpAddr, std::time::Instant>,
    pub static_banned_peers: HashSet<PeerId>,
     pending_dials: HashSet<PeerId>,
}

impl MidstateNetwork {
    /// `webrtc_cert` is the DTLS certificate whose fingerprint becomes the
    /// `/certhash/` component of every `/webrtc-direct/` listen address.
    /// Pass `Some` to keep that address stable across restarts; `None`
    /// generates an ephemeral one, which is fine for short-lived tooling but
    /// means saved multiaddrs stop resolving after a restart.
    pub async fn new(
        keypair: Keypair,
        listen_addr: Multiaddr,
        bootstrap_peers: Vec<Multiaddr>,
        static_banned_peers: HashSet<PeerId>,
        webrtc_cert: Option<libp2p_webrtc::tokio::Certificate>,
    ) -> Result<Self> {
        let peer_id = keypair.public().to_peer_id();
        tracing::info!("Local peer id: {}", peer_id);

        // Consumed inside the transport closure below. `take()` rather than a
        // move so this compiles whether the builder wants FnOnce or FnMut.
        let mut webrtc_cert = webrtc_cert;

        let mut swarm = libp2p::SwarmBuilder::with_existing_identity(keypair.clone())
            .with_tokio()
            .with_tcp(
                tcp::Config::default().nodelay(true),
                noise::Config::new,
                yamux::Config::default,
            )?
            .with_quic()
.with_other_transport(move |keypair| {
                let certificate = match webrtc_cert.take() {
                    Some(cert) => cert,
                    None => libp2p_webrtc::tokio::Certificate::generate(&mut rand::rngs::OsRng)
                        .expect("WebRTC certificate generation"),
                };


                Ok::<_, Box<dyn std::error::Error + Send + Sync>>(
                    libp2p_webrtc::tokio::Transport::new(keypair.clone(), certificate)
                        .map(|(peer_id, conn), _| (peer_id, StreamMuxerBox::new(conn)))
                )
            })?
            .with_relay_client(noise::Config::new, yamux::Config::default)?
            .with_behaviour(|key: &libp2p::identity::Keypair, relay_client| {
                let local_peer = key.public().to_peer_id();

            // --- decrease to 60s to PREVENT SYNC TIMEOUTS
                let rr_config = RequestResponseConfig::default()
                    .with_request_timeout(Duration::from_secs(60));

                let rr = request_response::Behaviour::new(
                    [(MIDSTATE_PROTOCOL, ProtocolSupport::Full)],
                    rr_config,
                );
                // -------------------------------------------------

                let light = libp2p_stream::Behaviour::new();
                let kad_store = kad::store::MemoryStore::new(local_peer);
                let mut kademlia = kad::Behaviour::new(local_peer, kad_store);
                kademlia.set_mode(Some(kad::Mode::Client));

                let identify = identify::Behaviour::new(
                    identify::Config::new(
                        "/midstate/id/2.0.0".to_string(),
                        key.public(),
                    )
                    .with_push_listen_addr_updates(true)
                    .with_interval(Duration::from_secs(60)),
                );

// RELAY CHOKE: Protect our outbound bandwidth from free-riders.
                // We provide just enough bandwidth for light clients to submit
                // transactions, but cut off heavy data streaming.
                let mut relay_config = relay::Config::default();
                relay_config.max_circuits = 32;                 // Max 16 total relayed connections
                relay_config.max_circuits_per_peer = 4;         // Prevent 1 peer taking all 16 slots
                relay_config.max_circuit_duration = std::time::Duration::from_secs(10 * 60); // 10 min max
                relay_config.max_circuit_bytes = 33_554_432;     // 32 MB data limit per circuit

                let relay_server = relay::Behaviour::new(
                    local_peer,
                    relay_config,
                );

                let dcutr = dcutr::Behaviour::new(local_peer);

let autonat = autonat::Behaviour::new(
                    local_peer,
                    autonat::Config {
                        boot_delay: Duration::from_secs(10),
                        refresh_interval: Duration::from_secs(120),
                        retry_interval: Duration::from_secs(60),
                        throttle_server_period: Duration::from_secs(15),
                        only_global_ips: true,
                        ..Default::default()
                    },
                );

                // --- EFFICIENCY FIX: Prevent File Descriptor / Socket Exhaustion ---
                // In libp2p v0.52+, ConnectionLimits is a Behaviour, not a Swarm Config.
                let limits = libp2p::connection_limits::ConnectionLimits::default()
                    .with_max_established_per_peer(Some(20)) // INCREASED: Allow multi-transport + AutoNAT overlap
                    .with_max_pending_incoming(Some(500))
                    .with_max_established_incoming(Some(800))  // INCREASED: Allow hundreds of light clients
                    .with_max_established_outgoing(Some(200));
                let connection_limits = libp2p::connection_limits::Behaviour::new(limits);
                // -------------------------------------------------------------------

                MidstateBehaviour {
                    rr,
                    light,
                    kademlia,
                    identify,
                    relay_client,
                    relay_server,
                    dcutr,
                    autonat,
                    connection_limits, 
                }
            })?
            .with_swarm_config(|c: libp2p::swarm::Config| {
                c.with_idle_connection_timeout(Duration::from_secs(120))
            })
            .build();

        let (light_tx, light_rx) = tokio::sync::mpsc::unbounded_channel();

        let mut net = Self {
            light_incoming: swarm
                .behaviour_mut()
                .light
                .new_control()
                .accept(LIGHT_PROTOCOL)
                .expect("light protocol already registered"),
            swarm,
            light_rx,
            light_tx,
            light_guard: LightGuard::new(),
            light_peers: HashSet::new(),
            connected: HashMap::new(),
            pending_requests: HashMap::new(),
            nat_status: NatStatus::Unknown,
            declared_public: false,
            relay_reservations: HashSet::new(),
            listen_addrs: Vec::new(),
            external_addrs: Vec::new(),
            subnet_peers: HashMap::new(),
            banned_subnets: HashMap::new(),
            static_banned_peers,
            pending_dials: HashSet::new(), 
        };

        net.swarm.listen_on(listen_addr.clone())?;

        if let Some(quic_addr) = tcp_to_quic(&listen_addr) {
            match net.swarm.listen_on(quic_addr.clone()) {
                Ok(_) => tracing::info!("Also listening on QUIC: {}", quic_addr),
                Err(e) => tracing::debug!("QUIC listen failed (non-fatal): {}", e),
            }
        }
        // Listen for WebRTC direct connections from browsers
        if let Some(webrtc_addr) = tcp_to_webrtc(&listen_addr) {
            match net.swarm.listen_on(webrtc_addr.clone()) {
                Ok(_) => tracing::info!("WebRTC listening on {}", webrtc_addr),
                Err(e) => tracing::debug!("WebRTC listen failed (non-fatal): {}", e),
            }
        }
        

        for addr in &bootstrap_peers {
            if let Some(peer) = extract_peer_id(addr) {
                net.swarm.behaviour_mut().kademlia.add_address(&peer, addr.clone());
                // NOTE: we deliberately do NOT request a relay reservation here.
                // Doing it unconditionally at startup — before AutoNAT has any
                // verdict — makes a publicly routable node reserve circuits
                // through every bootstrap peer, which pollutes listen_addrs and
                // external_addrs with /p2p-circuit addresses. Because extract_ip()
                // returns the *first* IP in a multiaddr, a circuit address makes
                // the node believe its external IP is the relay's, and it then
                // advertises every one of its addresses under someone else's IP.
                // maintain_relays() handles this properly, on demand, and only
                // once AutoNAT has actually confirmed we are Private.
            }
            if let Err(e) = net.swarm.dial(addr.clone()) {
                tracing::warn!("Failed to dial {}: {}", addr, e);
            }
        }

        if !bootstrap_peers.is_empty() {
            if let Err(e) = net.swarm.behaviour_mut().kademlia.bootstrap() {
                tracing::debug!("Kademlia bootstrap not ready: {}", e);
            }
        }

        Ok(net)
    }

    pub fn has_light_peers(&self) -> bool {
        !self.light_peers.is_empty()
    }

    pub fn broadcast_light_push(&mut self, notification: &LightNotification) {
        if self.light_peers.is_empty() { return; }
        
        let bytes = serde_json::to_vec(notification).unwrap_or_default();
        let mut payload = (bytes.len() as u32).to_le_bytes().to_vec();
        payload.extend_from_slice(&bytes);
        
        let control = self.swarm.behaviour_mut().light.new_control();
        
        for &peer in &self.light_peers {
            let mut ctrl = control.clone();
            let data = payload.clone();
            
            tokio::spawn(async move {
                // Strict 5-second timeout prevents Reverse-Slowloris task leaks
                let _ = tokio::time::timeout(std::time::Duration::from_secs(5), async move {
                    if let Ok(mut stream) = ctrl.open_stream(peer, LIGHT_PUSH_PROTOCOL).await {
                        use futures::AsyncWriteExt;
                        let _ = stream.write_all(&data).await;
                        let _ = stream.close().await;
                    }
                }).await;
            });
        }
    }

/// Dynamically seeks out public peers to act as inbound relays if we are stuck behind a NAT.
    pub fn maintain_relays(&mut self) {
        // Only seek relays if we are confirmed Private, and have fewer than 2 active relays.
        if self.nat_status == NatStatus::Private && self.relay_reservations.len() < 2 {
            
            // Find peers we dialed successfully (meaning they are public),
            // who are not light clients, and not already acting as our relay.
            let mut candidates = Vec::new();
            for (peer, endpoint) in &self.connected {
                // A banned peer must never be selected as a relay: routing our
                // inbound traffic through a node we refuse to talk to means
                // advertising a circuit address that cannot carry a connection.
                if !self.light_peers.contains(peer)
                    && !self.relay_reservations.contains(peer)
                    && !self.static_banned_peers.contains(peer)
                {
                    if endpoint.is_dialer() {
                        candidates.push((*peer, endpoint.get_remote_address().clone()));
                    }
                }
            }

            use rand::seq::SliceRandom;
            if let Some((peer, addr)) = candidates.choose(&mut rand::thread_rng()) {
                // Construct the proper libp2p circuit relay multiaddr
                let mut base_addr = addr.clone();
                if !base_addr.to_string().contains("/p2p/") {
                    base_addr.push(libp2p::multiaddr::Protocol::P2p(*peer));
                }
                let relay_addr = base_addr.with(libp2p::multiaddr::Protocol::P2pCircuit);
                
                tracing::info!("Dynamic Relay: Requesting inbound routing from public peer {}", peer);
                if let Err(e) = self.swarm.listen_on(relay_addr) {
                    tracing::debug!("Failed to request relay from {}: {}", peer, e);
                }
            }
        }
    }

    // ── Public API ──────────────────────────────────────────────────────

    pub fn local_peer_id(&self) -> PeerId {
        *self.swarm.local_peer_id()
    }

    pub fn nat_status(&self) -> NatStatus {
        self.nat_status
    }

    /// Declares this node publicly reachable at `addr`, overriding AutoNAT.
    ///
    /// # Reasoning
    /// AutoNAT infers reachability by asking connected peers to dial back. That
    /// inference is unreliable: a node with a public IP, an open port, and live
    /// inbound connections has been observed transitioning
    /// `Public → Private` after several minutes of healthy operation. Because
    /// registry publication and DHT announcement are both gated on
    /// `nat_status != Private`, a false Private verdict silently stops both, and
    /// the node TTLs out of the seed registry an hour later with nothing in the
    /// logs to explain it.
    ///
    /// On a host where the operator *knows* the answer — a VPS with a static
    /// public IP and a forwarded port — inference should not get a vote. This is
    /// a deliberate, explicit, config-only override; the default remains
    /// AutoNAT.
    ///
    /// # Formal Specification
    ///
    /// ```text
    /// Pre:  addr is a directly routable multiaddr owned by this node
    /// Post:
    ///   declared_public' = true
    ///   nat_status'      = Public
    ///   addr ∈ external_addrs'
    ///   kademlia mode'   = Server
    ///   ∀ later AutoNAT verdicts v • nat_status' = Public   (override is sticky)
    /// ```
    ///
    /// # Safety / Invariants
    /// - **Operator responsibility:** declaring an unreachable address publishes
    ///   an undialable entry to the registry and DHT. It wastes other nodes'
    ///   dial budget; it cannot corrupt consensus.
    /// - **Sticky:** once set it is never cleared, so a later AutoNAT probe
    ///   failure cannot re-introduce the silent-stop failure this exists to
    ///   prevent.
    pub fn declare_public(&mut self, addr: Multiaddr) {
        if !crate::network::is_routable(&addr) {
            tracing::warn!(
                "Ignoring public_address {}: not a routable public address",
                addr
            );
            return;
        }

        tracing::info!("Operator-declared public address: {} (AutoNAT overridden)", addr);

        self.declared_public = true;
        self.nat_status = NatStatus::Public;

        self.swarm.add_external_address(addr.clone());
        if !self.external_addrs.contains(&addr) {
            self.external_addrs.push(addr);
        }

        self.swarm
            .behaviour_mut()
            .kademlia
            .set_mode(Some(kad::Mode::Server));

        self.publish_to_phonebook();
    }

    pub fn send(&mut self, peer: PeerId, msg: Message) {
        let req_id = self.swarm.behaviour_mut().rr.send_request(&peer, msg);
        self.pending_requests.insert(req_id, peer);
    }

    pub fn broadcast(&mut self, msg: Message) {
        let peers: Vec<PeerId> = self.connected.keys()
            .filter(|p| !self.light_peers.contains(p))
            .copied().collect();
        for peer in peers {
            self.send(peer, msg.clone());
        }
    }

    pub fn broadcast_except(&mut self, exclude: Option<PeerId>, msg: Message) {
        let peers: Vec<PeerId> = self.connected
            .keys()
            .filter(|&&p| Some(p) != exclude && !self.light_peers.contains(&p))
            .copied()
            .collect();
        for peer in peers {
            self.send(peer, msg.clone());
        }
    }
pub async fn observe_honest_light_peer(&self, peer: PeerId) {
        self.light_guard.observe_honest(peer).await;
    }
    pub async fn observe_adversarial_light_peer(&self, peer: PeerId) {
        self.light_guard.observe_adversarial(peer).await;
    }
    pub async fn peer_honesty_probability(&self, peer: &PeerId) -> f32 {
        let guard = self.light_guard.inner.lock().await;
        if let Some(state) = guard.peers.get(peer) {
            state.alpha as f32 / (state.alpha + state.beta) as f32
        } else {
            0.5 // Unknown peers start at 50% probability of honesty
        }
    }
    /// Returns true if this peer is a light-only client (WebRTC browser).
    pub fn is_light_peer(&self, peer: &PeerId) -> bool {
        self.light_peers.contains(peer)
    }

    pub fn respond(&mut self, channel: ResponseChannel<Message>, msg: Message) {
        if let Err(_) = self.swarm.behaviour_mut().rr.send_response(channel, msg) {
            tracing::warn!("Failed to send response (channel closed)");
        }
    }

    pub fn peer_count(&self) -> usize {
        self.connected.len()
    }

    pub fn connected_peers(&self) -> Vec<PeerId> {
        self.connected.keys().copied().collect()
    }

    pub fn peer_addrs(&self) -> Vec<String> {
        self.connected.keys().map(|p| p.to_string()).collect()
    }

    pub fn disconnect_peer(&mut self, peer: PeerId) {
        let _ = self.swarm.disconnect_peer_id(peer);
    }

    /// Extract the subnet of a connected peer to facilitate network-level bans
    pub fn peer_subnet(&self, peer: &PeerId) -> Option<IpAddr> {
        self.connected.get(peer).and_then(|endpoint| {
            let addr = endpoint.get_remote_address();
            extract_subnet(addr)
        })
    }

    pub fn add_kad_address(&mut self, peer: PeerId, addr: Multiaddr) {
        self.swarm.behaviour_mut().kademlia.add_address(&peer, addr);
    }

    pub fn random_peer(&self) -> Option<PeerId> {
        use rand::seq::IteratorRandom;
        self.connected
            .keys()
            .filter(|p| !self.light_peers.contains(p))
            .copied()
            .choose(&mut rand::thread_rng())
    }

    // ── PEX (Peer Exchange) ─────────────────────────────────────────

    /// Our own externally-reachable addresses (for advertising to peers).
    /// Prefers confirmed external addrs; falls back to listen addrs.
    pub fn advertisable_addrs(&self) -> Vec<String> {
        let local_id = *self.swarm.local_peer_id();
        let p2p_suffix = libp2p::multiaddr::Protocol::P2p(local_id);

        // Only a *direct* external address describes this node's own identity.
        // A relayed one describes a path through someone else's node and would
        // hand us the relay's IP via extract_ip().
        let external_ip = self.external_addrs.iter()
            .filter(|a| !a.iter().any(|p| p == libp2p::multiaddr::Protocol::P2pCircuit))
            .find_map(|a| extract_ip(a));

        let mut addrs: Vec<String> = self.listen_addrs.iter()
            .filter_map(|a| {
                let candidate = match external_ip {
                    Some(ip) => replace_ip(a, ip),
                    None => a.clone(),
                };

                // One routability gate covering both branches. Previously the
                // external_ip branch skipped this check entirely, so loopback and
                // 0.0.0.0 listeners were IP-rewritten and then advertised, and
                // /p2p-circuit addresses passed through untouched.
                if !crate::network::is_routable(&candidate) {
                    return None;
                }

                let s = candidate.to_string();
                if s.contains("/p2p/") {
                    Some(s)
                } else {
                    Some(candidate.with(p2p_suffix.clone()).to_string())
                }
            })
            .collect();

        // dedup() only removes *consecutive* duplicates, so it must be sorted
        // first — otherwise dupes silently eat into the registry's 20-address cap.
        addrs.sort();
        addrs.dedup();
        addrs
    }

    /// The subset of `advertisable_addrs()` that another *server* node can
    /// actually dial.
    ///
    /// # Reasoning
    /// `dial_addr` deliberately refuses webrtc-direct (it is a browser transport),
    /// so those addresses are dead weight in the seed registry: they consume
    /// slots in the registry's 50-address response and cause wasted dial attempts.
    /// They remain in `advertisable_addrs()` so browser light clients can still
    /// learn them via identify/PEX — only the registry gets the filtered set.
    pub fn dialable_addrs(&self) -> Vec<String> {
        self.advertisable_addrs()
            .into_iter()
            .filter(|a| !a.contains("/webrtc-direct"))
            .collect()
    }
    
    /// Publishes this node's public addresses to the stateless seed registry.
    ///
    /// # Reasoning
    /// Allows the network to organically sustain its bootstrap mechanism without
    /// central coordination. Once AutoNAT confirms the node is publicly routable,
    /// it registers its addresses so new nodes booting up can discover it.
    ///
    /// # Formal Specification
    ///
    /// ```text
    /// Pre:
    ///   - AutoNAT has NOT positively confirmed us as Private
    ///     (Unknown is permitted — see the deadlock note in the body)
    ///
    /// Post:
    ///   - Fire-and-forget HTTP POST containing public addresses is sent to registry.
    ///   - Node state remains completely unchanged.
    /// ```
    ///
    /// ```zed
    ///     PublishToPhonebook
    ///     ------------------
    ///     public_addrs : seq String
    ///     registry_url : String
    ///
    ///     pre  #public_addrs > 0
    ///     post HTTP POST payload { "addresses": public_addrs } to registry_url
    /// ```
    ///
    /// # Safety / Invariants
    /// - **Non-blocking:** The HTTP request is spawned in a detached Tokio task.
    ///   It MUST NOT await on the main network reactor thread, as a stalled
    ///   HTTP request would freeze the entire p2p event loop.
    /// - **Strict Routability:** Only addresses passing `is_routable` are sent. 
    ///   This prevents leaking local/private IPs (e.g., 10.x, 192.168.x) to the 
    ///   public registry, which would bloat the phonebook with unreachable nodes.
    pub fn publish_to_phonebook(&self) {
        // The NAT gate lives here, not at the call sites. Only a *positive*
        // AutoNAT Private verdict blocks publishing. Requiring `Public`
        // deadlocks the network: AutoNAT can only reach `Public` by probing
        // connected peers, and peers are only discoverable through this
        // registry. A node that drops to zero connections loses its probe
        // servers, falls off `Public`, silently stops refreshing, and TTLs out
        // of the registry an hour later.
        if self.nat_status == NatStatus::Private && !self.declared_public {
            tracing::debug!("Phonebook publish skipped: AutoNAT confirmed we are behind a NAT.");
            return;
        }

        let addrs: Vec<String> = self.dialable_addrs()
            .into_iter()
            .filter(|addr_str| {
                // The deployed registry silently drops any address >= 200 chars
                // and 400s the whole request above 20 addresses. If every
                // address is dropped it stores an empty list under our IP, which
                // is indistinguishable from "node offline". Pre-filter to match
                // the registry's contract exactly.
                if addr_str.len() >= 200 {
                    return false;
                }
                match addr_str.parse::<libp2p::Multiaddr>() {
                    Ok(ma) => crate::network::is_routable(&ma),
                    Err(_) => false,
                }
            })
            .take(20)
            .collect();

        if addrs.is_empty() { 
            tracing::debug!("Phonebook publish skipped: No public routable addresses available yet.");
            return; 
        }
        
        tracing::info!("Publishing {} addresses to live phonebook...", addrs.len());
        
        tokio::spawn(async move {
            let client = reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(5))
                .build()
                .unwrap_or_else(|_| reqwest::Client::new());
            
            match client.post("https://seeds.midstate.cash/announce")
                .json(&serde_json::json!({ "addresses": addrs }))
                .send()
                .await 
            {
                Ok(resp) => {
                    if resp.status().is_success() {
                        tracing::info!("Successfully published addresses to phonebook.");
                    } else {
                        let status = resp.status();
                        let text = resp.text().await.unwrap_or_default();
                        tracing::warn!("Phonebook rejected publish ({}): {}", status, text);
                    }
                }
                Err(e) => {
                    tracing::error!("Failed to reach phonebook for publish: {}", e);
                }
            }
        });
    }

    /// Multiaddrs of connected peers (from Kademlia routing table).
    /// These are candidates to send in PEX Addr messages.
    pub fn connected_peer_addrs(&mut self) -> Vec<String> {
        let mut addrs = Vec::new();
        for bucket in self.swarm.behaviour_mut().kademlia.kbuckets() {
            for entry in bucket.iter() {
                let peer = entry.node.key.preimage();
                if !self.connected.contains_key(peer) {
                    continue;
                }
                for addr in entry.node.value.iter() {
                    if is_localhost(addr) {
                        continue;
                    }
                    let a_str = addr.to_string();
                    if a_str.contains("/p2p/") {
                        addrs.push(a_str);
                    } else {
                        let full = addr.clone().with(libp2p::multiaddr::Protocol::P2p(*peer));
                        addrs.push(full.to_string());
                    }
                }
            }
        }
        addrs.truncate(MAX_PEX_ADDRS);
        addrs
    }

    /// Build the PEX addr list: our own addrs + known peer addrs.
    pub fn pex_addrs(&mut self) -> Vec<String> {
        let mut all = self.advertisable_addrs();
        all.extend(self.connected_peer_addrs());
        all.sort();
        all.dedup();
        all.truncate(MAX_PEX_ADDRS);
        all
    }



    /// Try to dial a multiaddr string. Ignores bad parses or dial failures.
    pub fn dial_addr(&mut self, addr_str: &str) {
        // SERVER-TO-SERVER WEBRTC LEAK FIX:
        if addr_str.contains("webrtc-direct") {
            return;
        }
        match addr_str.parse::<Multiaddr>() {
            Ok(addr) => {
                // A /p2p-circuit address is a *path* through a relay rather than a
                // direct address, so it correctly fails is_routable() — which is
                // what keeps relay paths out of the seed registry and the PEX
                // pool. It is still dialable, and dialing one is precisely how
                // DCUtR hole-punching to a NAT'd peer begins, so permit it here.
                let is_relayed = addr
                    .iter()
                    .any(|p| p == libp2p::multiaddr::Protocol::P2pCircuit);
                if !is_relayed && !is_routable(&addr) {
                    tracing::debug!("PEX ignoring non-routable address: {}", addr_str);
                    return;
                }

                if let Some(peer) = extract_peer_id(&addr) {
                    if self.static_banned_peers.contains(&peer) {
                        tracing::debug!("PEX ignoring statically banned peer: {}", peer);
                        return;
                    }
                    if self.connected.contains_key(&peer) || peer == *self.swarm.local_peer_id() {
                        return; 
                    }

                    // --- NEW: Prevent duplicate in-flight dials ---
                    if self.pending_dials.contains(&peer) {
                        return;
                    }

                    // --- Subnet Limit Defense ---
                    if let Some(subnet) = extract_subnet(&addr) {
                        if let Some(peers) = self.subnet_peers.get(&subnet) {
                            if peers.len() >= 4 && !peers.contains(&peer) {
                                tracing::debug!("PEX ignoring {}: subnet limit reached", addr_str);
                                return;
                            }
                        }
                    }
                    
                    self.pending_dials.insert(peer); // Track in-flight dial

                    if let Err(e) = self.swarm.dial(addr) {
                        self.pending_dials.remove(&peer); // Cleanup on sync failure
                        tracing::debug!("PEX dial {} failed: {}", addr_str, e);
                    }
                } else {
                    tracing::debug!("Ignoring PEX address without PeerId: {}", addr_str);
                }
            }
            Err(e) => {
                tracing::debug!("PEX ignoring bad multiaddr '{}': {}", addr_str, e);
            }
        }
    }

    // ── Event loop ──────────────────────────────────────────────────────

    pub async fn next_event(&mut self) -> NetworkEvent {
        loop {
            tokio::select! {
                // ── Incoming raw stream from a browser light client ──────
                Some((peer, stream)) = self.light_incoming.next() => {
                    // ── Gate 0: Static Ban ──
                    if self.static_banned_peers.contains(&peer) {
                        tracing::debug!("Light stream from statically banned peer {}, dropping", peer);
                        let _ = self.swarm.disconnect_peer_id(peer);
                        continue;
                    }

                    // ── Gate 1: Is peer banned? ──
                    if self.light_guard.is_banned(&peer).await {
                        tracing::debug!("Light stream from banned peer {}, dropping", peer);
                        continue;
                    }

                    // ── Gate 2: Rate limit / concurrent stream check ──
                    match self.light_guard.try_open_stream(peer).await {
                        Ok(()) => {}
                        Err(reason) => {
                            tracing::warn!("Light stream from {} denied: {}", peer, reason);
                            // If banned, disconnect them entirely
                            if reason.starts_with("banned") {
                                let _ = self.swarm.disconnect_peer_id(peer);
                            }
                            continue;
                        }
                    }

                    let tx = self.light_tx.clone();
                    let guard = self.light_guard.clone();
                    // Snapshot the current light-peer load. Only the network layer
                    // knows the live count (light_peers lives here, not in the node's
                    // get_state builder), so we use it to annotate the get_state
                    // response below for load-aware client placement.
                    let light_count = self.light_peers.len();
                    tokio::spawn(async move {
                        use light_protocol::{read_request_raw, write_response_raw, LightResponse};
                        let mut stream = stream;

                        // ── Read with timeout ──
                        let read_result = tokio::time::timeout(
                            Duration::from_secs(LIGHT_READ_TIMEOUT_SECS),
                            read_request_raw(&mut stream),
                        ).await;

                        let request = match read_result {
                            Ok(Ok(req)) => req,
                            Ok(Err(e)) => {
                                tracing::debug!("Light read error from {}: {}", peer, e);
                                guard.close_stream(peer).await;
                                return;
                            }
                            Err(_) => {
                                tracing::debug!("Light read timeout from {}", peer);
                                guard.close_stream(peer).await;
                                return;
                            }
                        };

                        // ── Gate 3: Expensive request throttle ──
                        let is_expensive = matches!(
                            request, 
                            LightRequest::BlockTemplate { .. } | LightRequest::GetFilters { .. }
                        );
                        if is_expensive && !guard.check_expensive(peer).await {
                            tracing::warn!("Light {}: BlockTemplate rate limit hit", peer);
                            let _ = write_response_raw(
                                &mut stream,
                                LightResponse::error("rate limit: too many template requests"),
                            ).await;
                            guard.close_stream(peer).await;
                            return;
                        }

                        tracing::debug!("Light request from {}: {:?}", peer, request);

                        // ── Send to node for processing ──
                        // Capture this before `request` is moved into the channel, so
                        // we can annotate the get_state response with live load below.
                        let is_get_state = matches!(request, LightRequest::GetState);
                        let (resp_tx, resp_rx) = tokio::sync::oneshot::channel::<LightResponse>();
                        if tx.send((peer, request, resp_tx)).is_err() {
                            guard.close_stream(peer).await;
                            return;
                        }

                        // ── Await response with timeout ──
                        let mut resp = match tokio::time::timeout(
                            Duration::from_secs(LIGHT_RESPONSE_TIMEOUT_SECS),
                            resp_rx,
                        ).await {
                            Ok(Ok(resp)) => resp,
                            Ok(Err(_)) => LightResponse::error("internal error"),
                            Err(_) => {
                                tracing::warn!("Light {}: node response timeout", peer);
                                LightResponse::error("server timeout")
                            }
                        };

                        // Annotate get_state with the current light-peer load so
                        // wallets can spread across nodes (load-aware placement).
                        // light_count is a snapshot taken when the stream was accepted;
                        // a few seconds of staleness is fine for a placement hint.
                        if is_get_state {
                            if let Some(serde_json::Value::Object(ref mut map)) = resp.data {
                                map.insert(
                                    "light_connections".to_string(),
                                    serde_json::json!(light_count),
                                );
                                map.insert(
                                    "max_light_connections".to_string(),
                                    serde_json::json!(MAX_LIGHT_PEERS),
                                );
                            }
                        }

                        // ── Write response ──
                        // Enforce a strict timeout. If the WebRTC client is dead or malicious
                        // and stops reading, this prevents the task from hanging forever,
                        // which allows libp2p to drop the connection and webrtc-rs to GC the UDP socket.
                        let write_fut = write_response_raw(&mut stream, resp);
                        if let Err(_) = tokio::time::timeout(Duration::from_secs(5), write_fut).await {
                            tracing::debug!("Light {}: write timed out (client stalled)", peer);
                        }

                        guard.close_stream(peer).await;
                    });
                    continue;
                }

                // ── Light requests parsed by spawned tasks ──────────────
                Some((peer, request, respond)) = self.light_rx.recv() => {
                    return NetworkEvent::LightRequest { peer, request, respond };
                }

                event = self.swarm.select_next_some() => match event {
                // ── Request-Response ────────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Rr(
                    request_response::Event::Message { peer, message , ..},
                )) => match message {
                    request_response::Message::Request {
                        request, channel, ..
                    } => {
                        return NetworkEvent::MessageReceived {
                            peer,
                            message: request,
                            channel: Some(channel),
                        };
                    }
                    request_response::Message::Response {
                        request_id,
                        response,
                    } => {
                        self.pending_requests.remove(&request_id);
                        return NetworkEvent::MessageReceived {
                            peer,
                            message: response,
                            channel: None,
                        };
                    }
                },
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Rr(
                    request_response::Event::OutboundFailure {
                        peer,
                        request_id,
                        error,
                        ..
                    },
                )) => {
                    self.pending_requests.remove(&request_id);
                    // Deterministic, unlike Timeout / DialFailure / ConnectionClosed:
                    // a peer that speaks none of our protocols will never start,
                    // so retrying is pure noise. Ban on first occurrence.
                    if matches!(error, request_response::OutboundFailure::UnsupportedProtocols) {
                        return NetworkEvent::ProtocolMismatch(peer);
                    }

                    tracing::warn!("Outbound request to {} failed: {}", peer, error);
                    return NetworkEvent::RequestFailed(peer);
                }
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Rr(
                    request_response::Event::InboundFailure { peer, error, .. },
                )) => {
                    tracing::warn!("Inbound request from {} failed: {}", peer, error);
                }
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Rr(
                    request_response::Event::ResponseSent { .. },
                )) => {}

                // ── Identify ────────────────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Identify(
                    identify::Event::Received { peer_id, info, .. },
                )) => {
                    // FOREIGN NETWORK ISOLATION:
                    // Our Kademlia uses libp2p's default protocol name,
                    // "/ipfs/kad/1.0.0". Once this node announces itself on the
                    // public Amino DHT, IPFS peers learn our address and dial in
                    // — and without this check their listen addrs would enter the
                    // Midstate routing table and then be gossiped to other
                    // Midstate nodes via PEX (connected_peer_addrs reads the
                    // kbuckets). Only peers that actually speak the Midstate
                    // protocol may populate our address graph.
                    if !info.protocols.iter().any(|p| *p == MIDSTATE_PROTOCOL) {
                        tracing::debug!(
                            "Ignoring identify from non-Midstate peer {} ({} protocols)",
                            peer_id,
                            info.protocols.len()
                        );
                        continue;
                    }

                    for addr in &info.listen_addrs {
                        // SERVER-TO-SERVER WEBRTC LEAK FIX:
                        // Prevent Kademlia from learning and autonomously dialing WebRTC addresses.
                        if addr.to_string().contains("webrtc-direct") {
                            continue;
                        }
                        
                        self.swarm
                            .behaviour_mut()
                            .kademlia
                            .add_address(&peer_id, addr.clone());
                    }
                    self.swarm
                        .behaviour_mut()
                        .autonat
                        .add_server(peer_id, Some(info.observed_addr.clone()));
                }

                // ── libp2p_stream produces no swarm events for light ─────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Light(_)) => {}


                // ── AutoNAT ─────────────────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Autonat(
                    autonat::Event::StatusChanged { old, new },
                )) => {
                    tracing::info!("AutoNAT status: {:?} → {:?}", old, new);

                    // An operator declaration wins. AutoNAT flapping back to
                    // Private on a known-reachable host would otherwise stop
                    // registry publication and DHT announcement silently.
                    if self.declared_public {
                        tracing::debug!(
                            "Ignoring AutoNAT verdict: public address declared in config"
                        );
                        continue;
                    }

                    match new {
                        autonat::NatStatus::Public(_addr) => {
                            self.nat_status = NatStatus::Public;
                            self.swarm
                                .behaviour_mut()
                                .kademlia
                                .set_mode(Some(kad::Mode::Server));
                            tracing::info!(
                                "Node is PUBLIC — Kademlia server mode, serving as relay"
                            );

                            // --- PUBLISH TO PHONEBOOK ---
                            // We are publicly dialable! Announce ourselves to the registry
                            // so new nodes booting up can bootstrap from us.
                            self.publish_to_phonebook();
                        }
                        autonat::NatStatus::Private => {
                            self.nat_status = NatStatus::Private;
                            self.swarm
                                .behaviour_mut()
                                .kademlia
                                .set_mode(Some(kad::Mode::Client));
                            tracing::info!(
                                "Node is behind NAT — using relays and hole-punching"
                            );
                        }
                        autonat::NatStatus::Unknown => {
                            self.nat_status = NatStatus::Unknown;
                        }
                    }
                }

                // ── Relay client ────────────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::RelayClient(
                    relay::client::Event::ReservationReqAccepted {
                        relay_peer_id, ..
                    },
                )) => {
                    self.relay_reservations.insert(relay_peer_id);
                    tracing::info!(
                        "Relay reservation accepted by {} (total: {})",
                        relay_peer_id,
                        self.relay_reservations.len()
                    );
                }
                
                SwarmEvent::Behaviour(MidstateBehaviourEvent::RelayClient(event)) => {
                    tracing::debug!("Relay client event: {:?}", event);
                }

                // ── DCUtR (hole-punch) ──────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Dcutr(event)) => {
                    tracing::info!("DCUtR event: {:?}", event);
                }

                // ── Relay server ────────────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::RelayServer(event)) => {
                    tracing::debug!("Relay server event: {:?}", event);
                }

                // ── Kademlia ────────────────────────────────────────
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Kademlia(
                    kad::Event::RoutingUpdated { peer, .. },
                )) => {
                    tracing::debug!("Kademlia routing updated: {}", peer);
                }
                SwarmEvent::Behaviour(MidstateBehaviourEvent::Kademlia(_)) => {}

                // ── Catch-all ───────────────────────────────────────
                SwarmEvent::Behaviour(_) => {}

                // ── Connection lifecycle ─────────────────────────────
                SwarmEvent::ConnectionEstablished { peer_id, endpoint, num_established, .. } => {
                    // --- Ignore closures of self-connections ---
                    if peer_id == *self.swarm.local_peer_id() {
                        tracing::debug!("Ignoring self-connection");
                        let _ = self.swarm.disconnect_peer_id(peer_id);
                        continue;
                    }
                    
                    self.pending_dials.remove(&peer_id); 
                    
                    // --- STATIC BANNED PEER DEFENSE ---
                    if self.static_banned_peers.contains(&peer_id) {
                        tracing::warn!("Rejected connection from statically banned peer: {}", peer_id);
                        let _ = self.swarm.disconnect_peer_id(peer_id);
                        continue;
                    }

                    // --- DEDUPLICATION GATE ---
                    // If we already have 1 or more connections to this PeerID, 
                    // ignore this event. This prevents "flapping" when a peer 
                    // connects via multiple protocols (QUIC + TCP + WebRTC).
                    if num_established.get() > 1 {
                        tracing::debug!("Redundant connection established from {}; ignoring event.", peer_id);
                        continue;
                    }
                    // --------------------------

                    let remote_addr = endpoint.get_remote_address();
                    let is_webrtc = remote_addr.to_string().contains("webrtc-direct");

                    // --- Light peer cap ---
                    if is_webrtc && self.light_peers.len() >= MAX_LIGHT_PEERS {
                        tracing::warn!("Max light peers ({}) reached, dropping {}", MAX_LIGHT_PEERS, peer_id);
                        let _ = self.swarm.disconnect_peer_id(peer_id);
                        continue;
                    }

                    // --- Check if this light peer is banned ---
                    if is_webrtc && self.light_guard.is_banned(&peer_id).await {
                        tracing::warn!("Banned light peer {} reconnected, dropping", peer_id);
                        let _ = self.swarm.disconnect_peer_id(peer_id);
                        continue;
                    }

                   // --- Subnet Limit Defense ---
                    if let Some(subnet) = extract_subnet(remote_addr) {
                        let peers = self.subnet_peers.entry(subnet).or_default();
                        if !peers.contains(&peer_id) {
                            // Give WebRTC connections a much higher limit to handle 
                            // coffee shops, NATs, and developers refreshing the webpage.
                            let limit = if is_webrtc { 50 } else { 4 }; 
                            
                            if peers.len() >= limit { 
                                tracing::warn!("Eclipse Defense: Rejecting {}, subnet {} limit reached", peer_id, subnet);
                                let _ = self.swarm.disconnect_peer_id(peer_id);
                                continue;
                            }
                            peers.insert(peer_id);
                        }
                    }

                    // Eclipse Protection: Enforce inbound limit manually
                    if endpoint.is_listener() {
                        let inbound_count = self.connected.values().filter(|e| e.is_listener()).count();
                        if inbound_count >= 200 {
                            tracing::warn!("Max inbound peers (200) reached, dropping {}", peer_id);
                            let _ = self.swarm.disconnect_peer_id(peer_id);
                            continue; 
                        }
                    }

                    // Track WebRTC peers separately (don't add to Kademlia)
                    if is_webrtc {
                        self.light_peers.insert(peer_id);
                    } else {
                        self.swarm.behaviour_mut().kademlia.add_address(&peer_id, remote_addr.clone());
                    }

                    self.connected.insert(peer_id, endpoint.clone());
                    tracing::info!(
                        "Peer connected: {} via {:?} (total: {}, light: {})",
                        peer_id,
                        remote_addr,
                        self.connected.len(),
                        self.light_peers.len()
                    );
                    
                    // --- BAYESIAN ECLIPSE DEFENSE ---
                    // Construct the full PEX address string to pass to the node
                    let remote_str = remote_addr.to_string();
                    let full_addr = if remote_str.contains("/p2p/") {
                        remote_str
                    } else {
                        remote_addr.clone().with(libp2p::multiaddr::Protocol::P2p(peer_id)).to_string()
                    };
                    
                    return NetworkEvent::PeerConnected(peer_id, full_addr);
                }
                
                SwarmEvent::IncomingConnectionError { local_addr: _, send_back_addr, error, connection_id: _, ..} => {
                    // This event fires when a connection fails BEFORE Step 4 (Identify).
                    // Just log it. Do NOT insert PeerId::random() into self.subnet_peers, 
                    // as that permanently consumes valid connection slots and leads to 
                    // accidental network-wide bans for innocent QUIC packet drops.
                    if let Some(subnet) = crate::network::extract_subnet(&send_back_addr) {
                        tracing::trace!("Incoming transport error from subnet {}: {:?}", subnet, error);
                    }
                }
                SwarmEvent::ConnectionClosed {
                    peer_id,
                    endpoint,
                    num_established,
                    ..
                } => {
                    // --- Ignore closures of self-connections ---
                    if peer_id == *self.swarm.local_peer_id() {
                        continue;
                    }
                    
                    self.pending_dials.remove(&peer_id); 
                    // ------------------------------------------------
                    
                    if num_established == 0 {
                        self.connected.remove(&peer_id);
                        self.relay_reservations.remove(&peer_id); 
                        
                        // --- Light peer cleanup ---
                        if self.light_peers.remove(&peer_id) {
                            self.light_guard.remove_peer(&peer_id).await;
                        }
                        
                        // --- Subnet Limit Defense Cleanup ---
                        if let Some(subnet) = extract_subnet(endpoint.get_remote_address()) {
                            if let std::collections::hash_map::Entry::Occupied(mut entry) = self.subnet_peers.entry(subnet) {
                                entry.get_mut().remove(&peer_id);
                                if entry.get().is_empty() {
                                    entry.remove();
                                }
                            }
                        }
                        // -----------------------------------------

                        tracing::info!(
                            "Peer disconnected: {} (total: {}, light: {})",
                            peer_id,
                            self.connected.len(),
                            self.light_peers.len()
                        );
                        return NetworkEvent::PeerDisconnected(peer_id);
                    }
                }
                SwarmEvent::NewListenAddr { address, .. } => {
                    tracing::info!("Listening on {}", address);
                    self.listen_addrs.push(address);
                }
                SwarmEvent::OutgoingConnectionError { peer_id, error, .. } => {
                    // 1. If libp2p knows the PeerId natively, remove it.
                    if let Some(pid) = peer_id {
                        self.pending_dials.remove(&pid);
                    }

                    // 2. Extract failed multiaddrs and scrub them from pending_dials
                    match error {
                        libp2p::swarm::DialError::Transport(failed_addrs) => {
                            for (addr, _) in &failed_addrs {
                                if let Some(pid) = extract_peer_id(addr) {
                                    self.pending_dials.remove(&pid);
                                }
                            }
                            if let Some((multiaddr, _)) = failed_addrs.first() {
                                return NetworkEvent::OutgoingConnectionFailed(multiaddr.to_string());
                            }
                        }
                        libp2p::swarm::DialError::WrongPeerId { address, .. } => {
                            if let Some(pid) = extract_peer_id(&address) {
                                self.pending_dials.remove(&pid);
                            }
                            return NetworkEvent::OutgoingConnectionFailed(address.to_string());
                        }
                        _ => {}
                    }
                }
                SwarmEvent::ExternalAddrConfirmed { address } => {
                    tracing::info!("External address confirmed: {}", address);

                    // A confirmed *relayed* address tells us the relay's IP, not
                    // ours. extract_ip() returns the first IP in a multiaddr, so
                    // letting one into external_addrs makes advertisable_addrs()
                    // rewrite every address we own to the relay's IP — publishing
                    // someone else's server under our peer id.
                    let is_relayed = address
                        .iter()
                        .any(|p| p == libp2p::multiaddr::Protocol::P2pCircuit);

                    if is_relayed {
                        tracing::debug!(
                            "Ignoring relayed address as external identity: {}",
                            address
                        );
                    } else {
                        if !self.external_addrs.contains(&address) {
                            self.external_addrs.push(address);
                        }

                        // --- PUBLISH TO PHONEBOOK ---
                        // A confirmed external address is the strongest routability
                        // signal libp2p gives us, so publish unconditionally here.
                        // publish_to_phonebook() self-gates on a positive AutoNAT
                        // Private verdict.
                        self.publish_to_phonebook();
                    }
                }
                _ => {}
            } // match event
            } // tokio::select!
        } // loop
    }
    
    pub fn outbound_peer_count(&self) -> usize {
        self.connected.values().filter(|e| e.is_dialer()).count()
    }
    // respond_light is superseded: use the oneshot sender in NetworkEvent::LightRequest.
    // Kept as a stub so any stale call site produces a compile error rather than
    // a silent behaviour change.
    #[deprecated(note = "Send the response via the `respond` oneshot in NetworkEvent::LightRequest")]
    pub fn respond_light(&mut self, _resp: LightResponse) {
        unimplemented!("use NetworkEvent::LightRequest::respond oneshot")
    }

    /// Garbage-collect stale light client rate-limiter entries.
    /// Call periodically (e.g. every 60s) to prevent unbounded growth.
    pub async fn gc_stale_light_peers(&self) {
        self.light_guard.gc_stale().await;
    }
    
    /// Cancel any relay reservation held with this peer and stop advertising
    /// circuit addresses that route through it.
    pub fn drop_relay_reservation(&mut self, peer: PeerId) {
        if self.relay_reservations.remove(&peer) {
            let circuit = format!("/p2p/{peer}/p2p-circuit");
            self.external_addrs.retain(|a| !a.to_string().contains(&circuit));
            self.listen_addrs.retain(|a| !a.to_string().contains(&circuit));
            tracing::info!("Dropped relay reservation with banned peer {peer}");
        }
    }
    
}

// ── Helpers ──────────────────────────────────────────────────────────────────

pub fn socket_to_multiaddr(addr: SocketAddr) -> Multiaddr {
    use std::net::IpAddr;
    let mut ma = Multiaddr::empty();
    match addr.ip() {
        IpAddr::V4(ip) => ma.push(libp2p::multiaddr::Protocol::Ip4(ip)),
        IpAddr::V6(ip) => ma.push(libp2p::multiaddr::Protocol::Ip6(ip)),
    }
    ma.push(libp2p::multiaddr::Protocol::Tcp(addr.port()));
    ma
}

/// Convert a TCP multiaddr to its WebRTC-direct equivalent.
/// /ip4/0.0.0.0/tcp/9333 → /ip4/0.0.0.0/udp/9091/webrtc-direct
fn tcp_to_webrtc(addr: &Multiaddr) -> Option<Multiaddr> {
    let mut components = addr.iter().collect::<Vec<_>>();
    let tcp_idx = components.iter().position(|p| matches!(p, libp2p::multiaddr::Protocol::Tcp(_)))?;
    let port = match components[tcp_idx] {
        libp2p::multiaddr::Protocol::Tcp(p) => p,
        _ => return None,
    };
    // Use port + 2 to avoid colliding with QUIC (port + 0)
    let webrtc_port = port.checked_add(2).unwrap_or(port);
    components[tcp_idx] = libp2p::multiaddr::Protocol::Udp(webrtc_port);
    components.insert(tcp_idx + 1, libp2p::multiaddr::Protocol::WebRTCDirect);
    let mut ma = Multiaddr::empty();
    for c in components {
        ma.push(c);
    }
    Some(ma)
}

/// Convert a TCP multiaddr to its QUIC-v1 equivalent.
/// /ip4/0.0.0.0/tcp/9333 → /ip4/0.0.0.0/udp/9333/quic-v1
fn tcp_to_quic(addr: &Multiaddr) -> Option<Multiaddr> {
    let mut components = addr.iter().collect::<Vec<_>>();
    let tcp_idx = components.iter().position(|p| matches!(p, libp2p::multiaddr::Protocol::Tcp(_)))?;
    let port = match components[tcp_idx] {
        libp2p::multiaddr::Protocol::Tcp(p) => p,
        _ => return None,
    };
    components[tcp_idx] = libp2p::multiaddr::Protocol::Udp(port);
    components.insert(tcp_idx + 1, libp2p::multiaddr::Protocol::QuicV1);
    let mut ma = Multiaddr::empty();
    for c in components {
        ma.push(c);
    }
    Some(ma)
}

/// Extract PeerId from a multiaddr like /ip4/.../tcp/.../p2p/<peer_id>
fn extract_peer_id(addr: &Multiaddr) -> Option<PeerId> {
    addr.iter().find_map(|p| match p {
        libp2p::multiaddr::Protocol::P2p(peer_id) => Some(peer_id),
        _ => None,
    })
}

/// Extracts the /24 (IPv4) or /32 (IPv6) subnet prefix from a multiaddr.
/// Returns None for localhost addresses so local testing isn't restricted.
fn extract_subnet(addr: &Multiaddr) -> Option<IpAddr> {
    if is_localhost(addr) {
        return None;
    }
    // Relayed connections share the relay's IP. Do not rate-limit the relay itself.
    if addr.iter().any(|p| p == libp2p::multiaddr::Protocol::P2pCircuit) {
        return None;
    }
    addr.iter().find_map(|p| match p {
        libp2p::multiaddr::Protocol::Ip4(ip) => {
            let octets = ip.octets();
            // Mask to /24
            Some(IpAddr::V4(std::net::Ipv4Addr::new(octets[0], octets[1], octets[2], 0)))
        }
        libp2p::multiaddr::Protocol::Ip6(ip) => {
            let segs = ip.segments();
            // Mask to /32: A single /32 represents a standard ISP/LIR allocation.
            // This prevents an attacker with a single leased block from spoofing
            // thousands of independent subnets.
            Some(IpAddr::V6(std::net::Ipv6Addr::new(segs[0], segs[1], 0, 0, 0, 0, 0, 0)))
        }
        _ => None,
    })
}

/// Check if a multiaddr points to localhost/loopback.
fn is_localhost(addr: &Multiaddr) -> bool {
    addr.iter().any(|p| match p {
        libp2p::multiaddr::Protocol::Ip4(ip) => ip.is_loopback(),
        libp2p::multiaddr::Protocol::Ip6(ip) => ip.is_loopback(),
        _ => false,
    })
}

fn extract_ip(addr: &Multiaddr) -> Option<std::net::IpAddr> {
    for proto in addr.iter() {
        match proto {
            libp2p::multiaddr::Protocol::Ip4(ip) => return Some(std::net::IpAddr::V4(ip)),
            libp2p::multiaddr::Protocol::Ip6(ip) => return Some(std::net::IpAddr::V6(ip)),
            _ => {}
        }
    }
    None
}

fn replace_ip(addr: &Multiaddr, new_ip: std::net::IpAddr) -> Multiaddr {
    addr.iter().map(|proto| match proto {
        libp2p::multiaddr::Protocol::Ip4(_) => match new_ip {
            std::net::IpAddr::V4(ip) => libp2p::multiaddr::Protocol::Ip4(ip),
            std::net::IpAddr::V6(ip) => libp2p::multiaddr::Protocol::Ip6(ip),
        },
        libp2p::multiaddr::Protocol::Ip6(_) => match new_ip {
            std::net::IpAddr::V4(ip) => libp2p::multiaddr::Protocol::Ip4(ip),
            std::net::IpAddr::V6(ip) => libp2p::multiaddr::Protocol::Ip6(ip),
        },
        other => other,
    }).collect()
}

// ── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── Helper function tests ───────────────────────────────────────

    #[test]
    fn tcp_to_quic_basic() {
        let tcp: Multiaddr = "/ip4/0.0.0.0/tcp/9333".parse().unwrap();
        let quic = tcp_to_quic(&tcp).unwrap();
        assert_eq!(quic.to_string(), "/ip4/0.0.0.0/udp/9333/quic-v1");
    }

    #[test]
    fn tcp_to_quic_with_ip6() {
        let tcp: Multiaddr = "/ip6/::/tcp/9333".parse().unwrap();
        let quic = tcp_to_quic(&tcp).unwrap();
        assert_eq!(quic.to_string(), "/ip6/::/udp/9333/quic-v1");
    }

    #[test]
    fn tcp_to_quic_no_tcp_returns_none() {
        let udp: Multiaddr = "/ip4/0.0.0.0/udp/9333".parse().unwrap();
        assert!(tcp_to_quic(&udp).is_none());
    }

    #[test]
    fn tcp_to_quic_preserves_peer_id() {
        let tcp: Multiaddr = "/ip4/1.2.3.4/tcp/9333/p2p/12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN"
            .parse().unwrap();
        let quic = tcp_to_quic(&tcp).unwrap();
        let quic_str = quic.to_string();
        assert!(quic_str.contains("/udp/9333/quic-v1"));
        assert!(quic_str.contains("/p2p/12D3KooW"));
    }

    #[test]
    fn extract_peer_id_present() {
        let addr: Multiaddr = "/ip4/1.2.3.4/tcp/9333/p2p/12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN"
            .parse().unwrap();
        assert!(extract_peer_id(&addr).is_some());
    }

    #[test]
    fn extract_peer_id_absent() {
        let addr: Multiaddr = "/ip4/1.2.3.4/tcp/9333".parse().unwrap();
        assert!(extract_peer_id(&addr).is_none());
    }

    #[test]
    fn is_localhost_ipv4_loopback() {
        let addr: Multiaddr = "/ip4/127.0.0.1/tcp/9333".parse().unwrap();
        assert!(is_localhost(&addr));
    }

    #[test]
    fn routable_rejects_unspecified_and_cgnat() {
        // 0.0.0.0 is matched by none of is_loopback/is_private/is_link_local,
        // so it previously passed and could be gossiped as a dialable address.
        let wildcard: Multiaddr = "/ip4/0.0.0.0/tcp/9333".parse().unwrap();
        assert!(!is_routable(&wildcard));

        // RFC 6598 carrier-grade NAT: looks public, is not.
        let cgnat: Multiaddr = "/ip4/100.64.12.9/tcp/9333".parse().unwrap();
        assert!(!is_routable(&cgnat));

        let ula: Multiaddr = "/ip6/fd00::1/tcp/9333".parse().unwrap();
        assert!(!is_routable(&ula));
    }

    #[test]
    fn routable_rejects_relay_paths() {
        // A circuit address describes a path through a relay. Accepting it is
        // what let a relay's IP be published as this node's own identity.
        let circuit: Multiaddr =
            "/ip4/1.2.3.4/tcp/9333/p2p/12D3KooWPbR63SQg1UBLpAMiNngqrRHGM4LaMP8ieAJUxhfw7dxv/p2p-circuit"
                .parse()
                .unwrap();
        assert!(!is_routable(&circuit));
    }

    #[test]
    fn routable_still_accepts_ordinary_public_addrs() {
        let tcp: Multiaddr = "/ip4/74.208.253.44/tcp/9333".parse().unwrap();
        assert!(is_routable(&tcp));
        let quic: Multiaddr = "/ip4/74.208.253.44/udp/9333/quic-v1".parse().unwrap();
        assert!(is_routable(&quic));
    }

    #[test]
    fn is_localhost_ipv6_loopback() {
        let addr: Multiaddr = "/ip6/::1/tcp/9333".parse().unwrap();
        assert!(is_localhost(&addr));
    }

    #[test]
    fn is_localhost_public_ip() {
        let addr: Multiaddr = "/ip4/203.0.113.10/tcp/9333".parse().unwrap();
        assert!(!is_localhost(&addr));
    }

    #[test]
    fn socket_to_multiaddr_ipv4() {
        let sa: SocketAddr = "1.2.3.4:9333".parse().unwrap();
        let ma = socket_to_multiaddr(sa);
        assert_eq!(ma.to_string(), "/ip4/1.2.3.4/tcp/9333");
    }

    #[test]
    fn socket_to_multiaddr_ipv6() {
        let sa: SocketAddr = "[::1]:9333".parse().unwrap();
        let ma = socket_to_multiaddr(sa);
        assert_eq!(ma.to_string(), "/ip6/::1/tcp/9333");
    }

    // ── NAT status tests ────────────────────────────────────────────

    #[test]
    fn nat_status_default() {
        // Can't construct MidstateNetwork without async, but we can
        // test the enum directly
        let status = NatStatus::Unknown;
        assert_eq!(status, NatStatus::Unknown);
        assert_ne!(status, NatStatus::Public);
        assert_ne!(status, NatStatus::Private);
    }

    // ── PEX constant tests ──────────────────────────────────────────

    #[test]
    fn max_pex_addrs_is_reasonable() {
        // Sanity: the limit should be between 10 and 1000
        assert!(MAX_PEX_ADDRS >= 10);
        assert!(MAX_PEX_ADDRS <= 1000);
    }
}
